interface SuperHero
{
    realName:string;
    superName:string;
}

var sm1:SuperHero={

    realName:"Amitabh Bachhan",
    superName:"Shenhansha"
};



document.write("<br> <br> "+sm1.realName+" is "+sm1.superName);

var superheros:SuperHero[]=[];
superheros.push({realName:"Gangadhar", superName:"Shaktiman"});

document.write("<br> <br> "+superheros[0].realName+" hi "+superheros[0].superName);