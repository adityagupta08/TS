<div class='panel panel-primary'>

    <div class='panel-heading' style="text-align:center">

       {{pageTitle | uppercase}}

    </div>

    <div class='panel-body'>

        <div class='row'>

            <div class='col-md-2'>Filter by: </div>

                <div class="col-md-4"><input type="text" [(ngModel)]='listFilter'/>
                </div>
                

            
            

            <div class='col-md-2'>
                 <button class="btn btn-primary" (click)='toggleImage()'>{{showImage? 'Hide': 'Show'}} image</button>

            </div>

        </div>

       

        <div class='table-responsive'>

            <table class='table'*ngIf='products && products.length'>

                <thead>

                    <tr>

                        <th>

                            

                        </th>
                       

                        <th>Product</th>

                        <th>Code</th>

                        <th>Available</th>

                        <th>Price</th>

                        <th>5 Star Rating</th>

                    </tr>

                </thead>

                <tbody>
                    <tr *ngFor='#product of products | productFilter:listFilter'>
                        <td>
                            <img [src] ="product.imageUrl"
                            [title] = "product.productName"  
                            
                            [style.width.px]='imageWidth'
                            [style.margin.px]='imageMargin'

                            *ngIf='showImage'

                            />
                            </td>
                        <td>
                            {{product.productName}}
                        </td>
                        <td>
                            {{product.productCode | lowercase}}
                        </td>
                        <td>
                            {{product.Date}}
                            </td>
                        <td>
                            {{product.price | currency:'INR':true:'1.2-2'}}
                        </td>
                        <td>
                            {{product.starRating}}<ai-star [rating]='product.starRating' (ratingClicked)='onRatingClicked($event)'></ai-star>
                        </td>
                    </tr>

                    
                  

                </tbody>

            </table>

        </div>

    </div>

</div>