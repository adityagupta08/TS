interface vehicle
{
    drive():any;
}


class Car implements vehicle
{
    constructor(private wheels:number)
    {}

    drive():void
    {
        document.write("<br> The car drives with "+this.wheels+" wheels")
    }
}

class bicycle implements vehicle
{
    constructor(private wheel:number){}

    drive():void

    {
        document.write("<br> The bike drives with "+this.wheel+" wheels")
    }
}

var car = new Car(4);
var bike = new bicycle(2);
car.drive();
bike.drive();

document.write("<br><br>=======================================Task================================================================");







class Human
{
    constructor(private Fn:string, private Ln:string, private Height:number)
    {


    }
    Walk():void
    {
        document.write("Can Walk with Two Legs")
    }

    Talk():void
    {
         document.write("Can Walk with Two Legs")
    }

    Run():void
    {
         document.write("Can Run with Two Legs")
    }

    showDetails():void
    {
        document.write("<br> Fn :"+this.Fn+"<br> Ln "+this.Ln+"<br> Height "+this.Height);
    }


}

class Employee extends Human
{
    constructor(private empId:number, private Dept:string, private Salary:number, private DoJoining:string, Fn,Ln,Height)
    {
        super (Fn,Ln,Height);


    }
    

    code():void
    {
         document.write("Employee is a coder")
    }

    ReviewCode():void
    {
         document.write("Employee is a Review coder")
    }

    ApllyForLeave():void
    {
         document.write("Employee is Applying for leave")
    }

   /* get Salary():number

    {   
        return  this.Salary;
    }

    set Salary:void
    {
        
    }
*/
   

    showDetails():void

     {   
          super.showDetails();
         //document.write("<br> Fn :"+this.Fn+"<br> Ln "+this.Ln+"<br> Height "+this.Height);
          document.write("<br> Employee Id :"+this.empId+"<br> Dept "+this.Dept+"<br> Salary "+this.Salary+"<br> Date Of Joining "+this.DoJoining);
    }



}


class Manager extends Employee
{
    constructor(private ManagerOfTeam:string, empId:number, Dept:string ,Salary:number, DofJoining:string, Fn,Ln,Height )
    {
        super(empId,Dept,Salary,DofJoining,Fn,Ln,Height);
        
    }

    GenerateReport():void
    {
        document.write(this.ManagerOfTeam+"  Generate Reports ");
    }

    ApproveLeave():void
    {
         document.write(" Manager approves for leave");
    }

    AssignTaskttoEmp():void
    {
        document.write("Assign the task to Employess");
    }

    showDetails():void
    {
        super.showDetails();
        document.write("<br> Manager Of Team is "+this.ManagerOfTeam);
    }

}


var manager1 = new Manager("Ashish",101,"Computer Science",200000,"12/2/2018","Aditya","Gupta",5);
manager1.showDetails();



































