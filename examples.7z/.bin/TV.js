var tv = /** @class */ (function () {
    function tv(manu, s, p) {
        this.MaxChannels = 100;
        this.chanelNum = 0;
        this.isOn = true;
        this.volume = 0;
        this.maxvolume = 100;
        this.Manufacture = manu;
        this.size = s;
        this.Price = p;
    }
    tv.prototype.On = function () {
        if (this.isOn) {
            document.write("<br>Tv is On ");
            this.isOn = false;
        }
        else {
            document.write("<br>Switch On the Tv");
        }
    };
    tv.prototype.Off = function () {
        if (!this.isOn) {
            document.write("<br>Tv is Off ");
            this.isOn = true;
        }
        else {
            document.write("<br>Tv is Running");
        }
    };
    tv.prototype.changeChannel = function () {
        if (this.chanelNum < this.MaxChannels) {
            this.chanelNum += 1;
            document.write("<br>Channel No.  " + this.chanelNum);
        }
        else {
            document.write("<br>Tv is switched off");
        }
    };
    tv.prototype.IncreaseVolume = function () {
        if (this.volume < this.maxvolume) {
            this.volume += 1;
            document.write("<br>Volume Number:  " + this.volume);
        }
        else {
            document.write("<br>Volume : " + this.volume);
        }
    };
    tv.prototype.DecreaseVolume = function () {
        if (this.volume > 0) {
            this.volume -= 1;
            document.write("<br>Volume Number:  " + this.volume);
        }
        else {
            document.write("<br>Volume : " + this.volume);
        }
    };
    tv.prototype.getManufacturer = function () {
        return this.Manufacture;
    };
    tv.prototype.getSize = function () {
        return this.size;
    };
    tv.prototype.getPrice = function () {
        return this.Price;
    };
    return tv;
}());
var samsung = new tv("Samsung", 32, 3200);
document.write("Manufacturer of Tv is : " + samsung.getManufacturer());
document.write("<br>Size of Tv is : " + samsung.getSize());
document.write("<br>Price of Tv is : " + samsung.getPrice());
samsung.On();
samsung.changeChannel();
samsung.changeChannel();
samsung.changeChannel();
samsung.changeChannel();
samsung.IncreaseVolume();
samsung.IncreaseVolume();
samsung.IncreaseVolume();
samsung.IncreaseVolume();
samsung.DecreaseVolume();
samsung.DecreaseVolume();
samsung.DecreaseVolume();
samsung.DecreaseVolume();
samsung.Off();
