var Aclass = /** @class */ (function () {
    function Aclass() {
    }
    Aclass.prototype.add = function (v1, v2) {
        return v1 + v2;
    };
    return Aclass;
}());
var obj = new Aclass();
document.write(obj.add(2, 2));
