document.write("Hello world");

var myname:string = "aditya";

var mage:number= 32;

var canvote:boolean = true;

var anything:any="capgemini";

//document.getElementById("aa").innerHTML = "i am "+myname;

document.write("<br><br>"+"type of name "+typeof(myname));

document.write("<br><br>"+"type of mage "+typeof(mage));
document.write("<br><br>"+"type of name "+typeof(myname));


document.write("<br><br>"+"type of canvote "+typeof(canvote));

document.write("<br><br>"+"type of anything "+typeof(anything));


document.write("<br><br>"+"type of anything "+typeof(anything));

const pi=3.14;



var strtoNumber:number = parseInt("123");
var numbertoString:number=5;


document.write("<br><br>"+"strtoNumber is a  "+typeof(strtoNumber)+" "+strtoNumber);

document.write("<br><br>"+"numbertoStringr is a  "+typeof(numbertoString)+" "+numbertoString);
// ************** for with in return indexes of array****************

var rndmarray = [5,45,46,3423,522,24,2,24,234,2,234,23,]
for(var val in rndmarray)
{
	document.write("<br>val in array "+val+"   ----->> "+rndmarray[val]);

}

var mappedArray =rndmarray.map(Math.sqrt);

// *****************for with of return values of array************

for(var vl of mappedArray )
{
	document.write("<br>val in array ----- "+vl);

}
//********************* Arrow Function***********************
var addone=(x)=>{
    return x+1;
}
console.log(addone(1));

var addtwo=(x)=> x+1;

console.log("addtwo output"+addone(1));
document.write("<br><br>addtwo value"+addtwo(2));


var GetSum = function(num1:number, num2:number):number
{
    return num1+num2;

}

document.write("<br>Addition of Two Numbers: "+GetSum(2,2));

var GetMulti = (num1:number, num2:number):number=>  num1*num2;



document.write("<br>Multiplication of Two Numbers: "+GetMulti(3,2));


//********************* Reduce function*****************

// reduce function takes values from array and give 
// the output as a single value
// inside reduce we can call callback function
// after calculation the value is tored in total
// function inside reduce is given by us



var total=[2,3,4,4].reduce(

    function(a,b)
    {
        return a+b;
    }
);

document.write("<br>Addition through reduce ---->  "+total);


// ... Operator Function


var sumAll = function(...nums:number[]):void
{
    var sum = nums.reduce((a,b)=> a+b);
    document.write("<br><br>value of sumall values is ---> "+sum);
}

sumAll(2,2);
sumAll(2,3,4);

// **************** Class Demo********************


class Emp 
{
     Name:string="Aditya";
    getname()
    {
        return this.Name;
    }

    setName(name:string)
    {
        this.Name=name;
    }
}

var e1 = new Emp();
document.write("<br>Value of getname --->"+e1.getname());
document.write("<br>"+e1.Name);
var e2 = new Emp();
e2.setName("Gupta");
document.write("<br>value of setname ---> " +e2.getname());



class dept
{
    Name:string
    getname=()=>{return this.Name};
    setname=(name)=>{return this.Name=name};
}

var d1 = new dept();
document.write("<br>Value of getname --->"+d1.getname());

var d2 = new dept();
d2.setname("Harshita")

document.write("<br>Value of getname --->"+d2.getname());


//********************************************************** *

class car
{
    isItNeutral:boolean=true;
    speed:number=50;

    start():void
    {   
        if(this.isItNeutral)
        {   
            this.isItNeutral=false;
            document.write("<br><br>Car started");
        }
        else
        {
             document.write("<br>Bring car in neutral");
        }


    }

    stop():void
    {
        if(!this.isItNeutral)
        {   
            this.isItNeutral=true;
            document.write("<br>car Stopped");
        }
        else
        {
            document.write("<br>car is in neutral");
        }
    }

    increaseSpeed():void
    {
        if(!this.isItNeutral)
        {
            this.speed+=10;
            document.write("<br>Speed of car is "+this.speed);
        }
        else
        {
           document.write("<br>Car is in Neutral "); 
        }
    }

    decreaseSpeed():void
    {
        if(!this.isItNeutral)
        {
            this.speed-=10;
            document.write("<br>Sppeed of car is "+this.speed);
        }
        else
        {
           document.write("<br>Car is in Neutral "); 
        }
    }


}

var honda = new car();
honda.start();
honda.increaseSpeed();
honda.decreaseSpeed();

honda.decreaseSpeed();
honda.decreaseSpeed();

honda.stop(); 









