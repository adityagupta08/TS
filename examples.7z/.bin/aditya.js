document.write("Hello world");
var myname = "aditya";
var mage = 32;
var canvote = true;
var anything = "capgemini";
//document.getElementById("aa").innerHTML = "i am "+myname;
document.write("<br><br>" + "type of name " + typeof (myname));
document.write("<br><br>" + "type of mage " + typeof (mage));
document.write("<br><br>" + "type of name " + typeof (myname));
document.write("<br><br>" + "type of canvote " + typeof (canvote));
document.write("<br><br>" + "type of anything " + typeof (anything));
document.write("<br><br>" + "type of anything " + typeof (anything));
var pi = 3.14;
var strtoNumber = parseInt("123");
var numbertoString = 5;
document.write("<br><br>" + "strtoNumber is a  " + typeof (strtoNumber) + " " + strtoNumber);
document.write("<br><br>" + "numbertoStringr is a  " + typeof (numbertoString) + " " + numbertoString);
var rndmarray = [5, 45, 46, 3423, 522, 24, 2, 24, 234, 2, 234, 23,];
for (var val in rndmarray) {
    document.write("<br>val in array " + val + "   ----->> " + rndmarray[val]);
}
var mappedArray = rndmarray.map(Math.sqrt);
for (var _i = 0, mappedArray_1 = mappedArray; _i < mappedArray_1.length; _i++) {
    var vl = mappedArray_1[_i];
    document.write("<br>val in array " + vl);
}
