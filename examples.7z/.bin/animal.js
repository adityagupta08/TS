var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Animal = /** @class */ (function () {
    // We can either inintailise 
    function Animal(name, owner) {
        this.name = name;
        this.owner = owner;
        Animal.noOfAnimals++;
        this.name = name;
        this.owner = owner;
    }
    Animal.prototype.ownerInfo = function () {
        document.write("<br> " + this.name + " is own by " + this.owner);
    };
    Object.defineProperty(Animal.prototype, "weight", {
        get: function () {
            return this._weight;
        },
        set: function (w) {
            this._weight = w;
        },
        enumerable: true,
        configurable: true
    });
    //aname:string
    //aowner:string
    Animal.noOfAnimals = 0;
    return Animal;
}());
var dog = new Animal("Tuffy", "Aditya");
dog.weight = 100;
document.write("<br>" + dog.weight);
document.write("<br>" + Animal.noOfAnimals);
dog.ownerInfo();
var dog1 = new Animal("Tommy", "Aditya");
dog1.weight = 200;
document.write("<br>" + dog1.weight);
document.write("<br>" + Animal.noOfAnimals);
dog1.ownerInfo();
document.write(dog._weight);
var DomesticAnimals = /** @class */ (function (_super) {
    __extends(DomesticAnimals, _super);
    function DomesticAnimals(_typeOfWork, name, owner) {
        var _this = _super.call(this, name, owner) || this;
        _this._typeOfWork = _typeOfWork;
        return _this;
        //this._typeOfWork=_typeOfWork;
    }
    Object.defineProperty(DomesticAnimals.prototype, "typeOfWork", {
        get: function () {
            return this.typeOfWork;
        },
        set: function (s) {
            this.typeOfWork = s;
        },
        enumerable: true,
        configurable: true
    });
    return DomesticAnimals;
}(Animal));
var Horse = new DomesticAnimals("Riding", "Storm", "Aditya");
Horse.ownerInfo();
document.write("<br>" + Horse._typeOfWork);
Horse.weight = 350;
document.write("<br>" + Horse.weight);
