class Animal
{
    favFood:string
    //aname:string
    //aowner:string
    static noOfAnimals:number=0;
    _weight:number


    // We can either inintailise 





    constructor(private name:string, private owner:string)
    {
        Animal.noOfAnimals++;
        this.name=name;
        this.owner=owner;

    }



    ownerInfo()
    {
        document.write("<br> "+this.name+" is own by "+this.owner);
    }

    get weight():number
    {
        return this._weight;

    }
    set weight(w:number)
    {
         this._weight=w;

    }

}

var dog = new Animal("Tuffy","Aditya");

dog.weight=100;
document.write("<br>"+dog.weight);
document.write("<br>"+Animal.noOfAnimals);

dog.ownerInfo();


var dog1 =new Animal("Tommy","Aditya");

dog1.weight=200;
document.write("<br>"+dog1.weight);
document.write("<br>"+Animal.noOfAnimals);
dog1.ownerInfo();
document.write(dog._weight);



class DomesticAnimals extends Animal
{
    constructor(private _typeOfWork, name,owner)
    {
        super(name,owner);
        //this._typeOfWork=_typeOfWork;


    }

    get typeOfWork():string
    {
        return this.typeOfWork;
    }

    set typeOfWork(s:string)
    {
        this.typeOfWork=s;
    }
    
}

var Horse =new DomesticAnimals("Riding","Storm","Aditya");
Horse.ownerInfo();
document.write("<br>"+Horse._typeOfWork);
Horse.weight=350;
document.write("<br>"+Horse.weight);

