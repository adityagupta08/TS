var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Car = /** @class */ (function () {
    function Car(wheels) {
        this.wheels = wheels;
    }
    Car.prototype.drive = function () {
        document.write("<br> The car drives with " + this.wheels + " wheels");
    };
    return Car;
}());
var bicycle = /** @class */ (function () {
    function bicycle(wheel) {
        this.wheel = wheel;
    }
    bicycle.prototype.drive = function () {
        document.write("<br> The bike drives with " + this.wheel + " wheels");
    };
    return bicycle;
}());
var car = new Car(4);
var bike = new bicycle(2);
car.drive();
bike.drive();
document.write("<br><br>=======================================Task================================================================");
var Human = /** @class */ (function () {
    function Human(Fn, Ln, Height) {
        this.Fn = Fn;
        this.Ln = Ln;
        this.Height = Height;
    }
    Human.prototype.Walk = function () {
        document.write("Can Walk with Two Legs");
    };
    Human.prototype.Talk = function () {
        document.write("Can Walk with Two Legs");
    };
    Human.prototype.Run = function () {
        document.write("Can Run with Two Legs");
    };
    Human.prototype.showDetails = function () {
        document.write("<br> Fn :" + this.Fn + "<br> Ln " + this.Ln + "<br> Height " + this.Height);
    };
    return Human;
}());
var Employee = /** @class */ (function (_super) {
    __extends(Employee, _super);
    function Employee(empId, Dept, Salary, DoJoining, Fn, Ln, Height) {
        var _this = _super.call(this, Fn, Ln, Height) || this;
        _this.empId = empId;
        _this.Dept = Dept;
        _this.Salary = Salary;
        _this.DoJoining = DoJoining;
        return _this;
    }
    Employee.prototype.code = function () {
        document.write("Employee is a coder");
    };
    Employee.prototype.ReviewCode = function () {
        document.write("Employee is a Review coder");
    };
    Employee.prototype.ApllyForLeave = function () {
        document.write("Employee is Applying for leave");
    };
    /* get Salary():number
 
     {
         return  this.Salary;
     }
 
     set Salary:void
     {
         
     }
 */
    Employee.prototype.showDetails = function () {
        _super.prototype.showDetails.call(this);
        //document.write("<br> Fn :"+this.Fn+"<br> Ln "+this.Ln+"<br> Height "+this.Height);
        document.write("<br> Employee Id :" + this.empId + "<br> Dept " + this.Dept + "<br> Salary " + this.Salary + "<br> Date Of Joining " + this.DoJoining);
    };
    return Employee;
}(Human));
var Manager = /** @class */ (function (_super) {
    __extends(Manager, _super);
    function Manager(ManagerOfTeam, empId, Dept, Salary, DofJoining, Fn, Ln, Height) {
        var _this = _super.call(this, empId, Dept, Salary, DofJoining, Fn, Ln, Height) || this;
        _this.ManagerOfTeam = ManagerOfTeam;
        return _this;
    }
    Manager.prototype.GenerateReport = function () {
        document.write(this.ManagerOfTeam + "  Generate Reports ");
    };
    Manager.prototype.ApproveLeave = function () {
        document.write(" Manager approves for leave");
    };
    Manager.prototype.AssignTaskttoEmp = function () {
        document.write("Assign the task to Employess");
    };
    Manager.prototype.showDetails = function () {
        _super.prototype.showDetails.call(this);
        document.write("<br> Manager Of Team is " + this.ManagerOfTeam);
    };
    return Manager;
}(Employee));
var manager1 = new Manager("Ashish", 101, "Computer Science", 200000, "12/2/2018", "Aditya", "Gupta", 5);
manager1.showDetails();
