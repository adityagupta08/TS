import { Injectable } from '@angular/core';

import {Grocery} from '../app/grocery/grocery';
import {GROCERIES} from '../app/grocery/mock-groceries';

import {IElectronic} from '../app/electronics/electronics'
import {ELECTRONICS} from '../app/electronics/mock-electronics'

import {IAccessories} from '../app/accessories/accessories'
import {ACCESSORIES} from '../app/accessories/mock-accessories'

import {Stationary} from '../app/stationary/stationary'
import {STATIONARIES} from '../app/stationary/mock-stationaries'
import {Product} from './product/product'
import {IClothing} from '../app/clothing/cloth';
import {CLOTHING} from '../app/clothing/mock-clothes';



@Injectable({
  providedIn: 'root'
})
export class ProductService {
  static cartCount:number=0;
  productsInCart:Product[]=[];
  cartProductsId:number[]=[];
  constructor() { }
  getGroceries():Grocery[]{
    return GROCERIES;
  }

  getElectronics():IElectronic[]{
    return ELECTRONICS;
  }

  getAccessories():IAccessories[]{
    return ACCESSORIES;
  }

  getStationaries():Stationary[]{
    return STATIONARIES;
  }

  getClothing(): IClothing[]
  {
    return CLOTHING;
  } 
  getCartCount():number{
    return ProductService.cartCount;
  }
  setCartCount(count:number){
    ProductService.cartCount=count;
  }
  addProduct(proid,proName,proPrice,proImage):void{
    this.productsInCart[ProductService.cartCount]={id:proid,product:proName,price:proPrice,imageUrl:proImage};
    this.cartProductsId[ProductService.cartCount]=this.productsInCart[ProductService.cartCount].id;
    ProductService.cartCount++;
  }
  removeProduct(proid):void{
    for(var i=0;i<this.productsInCart.length;i++){
      if(this.productsInCart[i].id==proid){
          this.productsInCart.splice(i,1);
      }
    }
    var i=this.cartProductsId.indexOf(proid);
    this.cartProductsId.splice(i,1);
    ProductService.cartCount--;
    
  }
  getProductsInCart():Product[]{
    return this.productsInCart;
  }

  getCartProductsId():number[]{
    return this.cartProductsId;
  }

  clearCart():void{
    this.productsInCart=[];
    this.cartProductsId=[];
    ProductService.cartCount=0;
  }
}
