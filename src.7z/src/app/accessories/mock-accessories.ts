import { IAccessories } from '../accessories/accessories';

export const ACCESSORIES: IAccessories[] = [
  { id: 5551, product: 'Handbag', price:3000, discount:'20 %',description:'Baggit Women Hand Bag',imageUrl:'assets/image/handbag.jpg'},
  { id: 5552, product: 'Watch', price:400, discount:'15 %',description:'Audemars Piguet',imageUrl:'assets/image/watch.jpg' },
  { id: 5553, product: 'Shoes', price:1000, discount:'15 %',
  description: 'Adidas Mens Shoe',imageUrl:'assets/image/shoe.jpg' }
]




