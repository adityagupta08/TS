import { Component, OnInit } from '@angular/core';
import {Product} from '../product/product'
import {ProductService} from '../product.service'
@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
  productsInCart:Product[]=[];
  imageWidth:number=200;
  imageHeight:number=150;
  total:number;
  constructor(private productService:ProductService) { }
  
  displayCart():void{
    this.productsInCart=[];
    this.productsInCart=this.productService.getProductsInCart();
  }
  calculateTotal(){
    this.total=0;
    for(var pro of this.productsInCart){
      this.total+=pro.price;
    }
  }
  ngOnInit() {
    this.displayCart();
    this.calculateTotal();
  }
  removeFromCart(proid){
  this.productService.removeProduct(proid);
  this.calculateTotal();
}
buyNow(proid){
  alert("Thank you for Shopping with us!");
  this.productService.clearCart();
  this.displayCart();
}
}
