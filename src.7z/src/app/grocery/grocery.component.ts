import { Component, OnInit } from '@angular/core';
import {Grocery} from './grocery';
import {ProductService} from '../product.service'


@Component({
  selector: 'app-grocery',
  templateUrl: './grocery.component.html',
  styleUrls: ['./grocery.component.css']
})
export class GroceryComponent implements OnInit {

 groceries:Grocery[];
 cartProductsId:number[];
  constructor(private productService:ProductService) { }
 getGroceries():void{
   this.groceries=this.productService.getGroceries();
 }
  ngOnInit() {
   this.getGroceries();
   this.cartProductsId=this.productService.getCartProductsId();
  }
 addToCart(proid,proName,proPrice,proImage){
  // sessionStorage.setItem('id',proid);
  // sessionStorage.setItem('product',proName);
  // sessionStorage.setItem('price',proPrice);
  // sessionStorage.setItem('image',proImage);
  this.productService.addProduct(proid,proName,proPrice,proImage);
  this.cartProductsId=this.productService.getCartProductsId();
}
removeFromCart(proid){
  this.productService.removeProduct(proid);
  this.cartProductsId=this.productService.getCartProductsId();
}
}
