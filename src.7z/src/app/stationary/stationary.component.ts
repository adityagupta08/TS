import { Component, OnInit } from '@angular/core';
import {Stationary} from './stationary';
import {ProductService} from '../product.service'

@Component({
  selector: 'app-stationary',
  templateUrl: './stationary.component.html',
  styleUrls: ['./stationary.component.css']
})
export class StationaryComponent implements OnInit {

   stationaries:Stationary[];
   cartProductsId:number[];
  constructor(private productService:ProductService) { }
  getStationaries():void{
    this.stationaries=this.productService.getStationaries();
  }
  ngOnInit() {
    this.getStationaries();
    this.cartProductsId=this.productService.getCartProductsId();
  }
  addToCart(proid,proName,proPrice,proImage){
  // sessionStorage.setItem('id',proid);
  // sessionStorage.setItem('product',proName);
  // sessionStorage.setItem('price',proPrice);
  // sessionStorage.setItem('image',proImage);
  this.productService.addProduct(proid,proName,proPrice,proImage);
  this.cartProductsId=this.productService.getCartProductsId();
}
removeFromCart(proid){
  this.productService.removeProduct(proid);
  this.cartProductsId=this.productService.getCartProductsId();
}
}
